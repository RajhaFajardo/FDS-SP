function irParaPagina(indice) {
    let paginas = document.querySelectorAll('.pagina');

    for (let pagina of paginas) {
        pagina.classList.remove('ativa');
    }

    paginas[indice].classList.add('ativa');
}