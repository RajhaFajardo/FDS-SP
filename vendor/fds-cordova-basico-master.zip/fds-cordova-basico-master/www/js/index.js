/**
 * Verifica se todos os campos do formulario estão preenchidos.
 */
function cadastrar() {
    //Pega os valores que foram digitados pelo usuário nos campos do formulario.
    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;
    let confirmaSenha = document.getElementById("confirmaSenha").value;

    //Verifica se algum campo está vazio.
    if (nome == "" || email == "" || senha == "" || confirmaSenha == "") {
        alert("Preencha os dados corretamente");//exibe mensagem
    }

    //Se todos os campos do formulário foram preenchidos 
    else{    
        alert("Cadastro realizado com sucesso");//exibe mensagem
        irParaPagina(2);//troca a tela
    }

}